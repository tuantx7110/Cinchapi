package com.cinchapi;

public class Entry {
	long value;
	Entry next=null;
	public Entry(long value)
	{
		this.value=value;
	}

	public Entry getNext() {
		return next;
	}

	public void setNext(Entry next) {
		this.next = next;
	}

	public long getValue() {
		return value;
	}

	public void setValue(long value) {
		this.value = value;
	}
}
