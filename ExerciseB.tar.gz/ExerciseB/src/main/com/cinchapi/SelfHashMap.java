package com.cinchapi;

/*
 * This is data structure that is similar to HashMap in Java core
 * However, in this data structure the key and the value are the same
 */
public class SelfHashMap {
	private static SelfHashMap map;
	private Entry[] table;
	private int numberOfElements;
	private double loadFactor = 1;

	private SelfHashMap(int size) {

		table = new Entry[size];

	}

	public static SelfHashMap getInstance(int size) {
		if (map == null)
			map = new SelfHashMap(size);
		return map;
	}
	/**
	 * This function will resize the table by creating new table and copy all element to it.
	 */

	private void resize() {
		int newSize = (int) (table.length * 1.5);
		Entry[] newTable = new Entry[newSize];
		for (int i = 0; i < table.length; i++) {
			if (table[i] != null) {
				Entry entry = table[i];
				while (entry != null) {
					long value=entry.getValue();
					int newIndex=(int) (hash(value)%newTable.length);
					//Insert into new table
					if(newTable[newIndex]==null)
					{
						newTable[newIndex] =new Entry(value);
					}
					else
					{
						Entry cur=newTable[newIndex];
						while(true)
						{
							if(cur.getNext()==null)break;
							cur=cur.getNext();
						}
						cur.setNext(new Entry(value));
						
					}
					
					entry=entry.getNext();
					

				}

			}
		}
		table=newTable;

	}

	/**
	 * Attempt to insert {@code value} into the collection and return
	 * {@code true} if the collection is modified after this method returns
	 * (e.g. {@code value} was not already contained in the collection)
	 * 
	 * @param value
	 *            a long value to insert into the collection
	 * @return {@code true} if {@code value} didn't previously exist in the
	 *         collection and is inserted
	 */
	public boolean insert(long value) {
		if(numberOfElements>=((int)(table.length*loadFactor)))
		{
			resize();
		}
		int index=(int) (hash(value)%table.length);
		
		if(table[index]==null)
		{
			table[index]=new Entry(value);
			return true;
		}
		Entry entry=table[index];
		
		while(true)
		{
			if(entry.getValue()==value)return false;
			if(entry.getNext()==null)break;			
			entry=entry.next;
		}
		entry.setNext(new Entry(value));
		return true;
		

	}

	/**
	 * Return {@code true} if {@code value} exists within the collection.
	 * 
	 * @param value
	 *            the value for which to check
	 * @return {@code true} if {@code value} is contained within the collection
	 */
	public boolean contains(long value) {
		int index = (int) (hash(value) % table.length);
		if (table[index] == null)
			return false;
		else {
			Entry entry = table[index];
			while (entry != null) {
				if(entry.getValue()==value) return true;
				entry=entry.getNext();
			}

		}
		return false;

	}
	/**
	 *  Calculating the hash of value
	 * @param h the value
	 * @return hash of value
	 */

	public static long hash(long h) {
		h ^= (h >>> 20) ^ (h >>> 12);
		return h ^ (h >>> 7) ^ (h >>> 4);

	}
	
	
	public static void main(String args)
	{
		int numberOfElements=10000000;
		SelfHashMap map=SelfHashMap.getInstance(10000000);
		for(int i=0;i<numberOfElements;i++)
		{
			map.insert(i);
		}
	}

}
