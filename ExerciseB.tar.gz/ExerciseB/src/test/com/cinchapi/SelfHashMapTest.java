package com.cinchapi;

import static org.junit.Assert.*;

import org.junit.Test;

public class SelfHashMapTest {

	@Test
	public void testInsert() {
		
//		SelfHashMap map=SelfHashMap.getInstance(10000);
//		assertEquals("Insert fail when the map is empty",true,map.insert(1000));
//		assertEquals("Insert fail when element is not in the map",true,map.insert(100));
//		assertEquals("Insert fail when element is in the map",false,map.insert(100));
	}

	@Test
	public void testContains() {
		SelfHashMap map=SelfHashMap.getInstance(10000);
		for(long i=10;i<5000;i++)map.insert(i);
		
		assertEquals("Contain fail when the element is in the map",true,map.contains(1000));
		assertEquals("Contain fail when the element is not in the map",false,map.contains(100000));
	}
	
}
