package com.cinchapi;
import java.lang.instrument.Instrumentation;
import java.util.ArrayList;
import java.util.HashMap;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;

public class TestSpaceComplexity {

	public static void main(String[] args) {
//		int numberOfElements=10000000;
//		SelfHashMap map=SelfHashMap.getInstance(10000000);
//		for(int i=0;i<numberOfElements;i++)
//		{
//			map.insert(i);
//		}
//		
//		System.out.println("Contain 10000 ? " +map.contains(10000));
		 System.out.println("start");
	int numberOfElements=10000000;
	LongBuffer buffer=ByteBuffer.allocateDirect(80000000).asLongBuffer();
	 for(int i=0;i<numberOfElements;i++)
	 {
		 buffer.put(i, i);
	 }
	 
	 System.out.println("finish");

	}

}
